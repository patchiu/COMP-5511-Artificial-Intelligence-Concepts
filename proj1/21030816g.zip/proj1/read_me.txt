Project 1.pdf is my report.

GA , restriction_S_E is the code. 
There are .html and .ipynb fromat.
Those are python code.

city_data.csv is the city locaton data for 10 cities.
city_data_13.csv is the city locaton data for part of Introduce more cities.
city_data_restr.csv is the city locaton data for restrictions on the start and end point.